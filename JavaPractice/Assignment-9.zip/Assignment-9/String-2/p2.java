//  Write a Java program to get the character at the given index within the String
class Main{
    public static void main(String[] args) {
        String str = ""
}