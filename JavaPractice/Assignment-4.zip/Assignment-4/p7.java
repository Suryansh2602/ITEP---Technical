import java.util.Scanner;
class p1{
    public static void main(String args[]){
    Scanner sc= new Scanner(System.in);
    System.out.println("Enter the number : ");
    int n=sc.nextInt();
    int i=1;
    while(i<=10){
        System.out.println(i*n);
        i++;
    }
    }
}
/**4) WAP to print table of a number. */