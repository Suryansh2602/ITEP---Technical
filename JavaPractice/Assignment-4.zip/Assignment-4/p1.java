class p1{
    public static void main(String args[]){
        int i=1;
        while (i<=1000){
            System.out.println("Statement : "+i);
            i++;
        }
    }
}
/*1) WAP to print a statement 1000 number of times.
2) WAP to print N natural number.  

/