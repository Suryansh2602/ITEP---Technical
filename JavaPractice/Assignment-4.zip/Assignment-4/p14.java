// WAP to print alphabets in uppercase
class P{
public static void main(String[] args) {
    char a = 'A';
    while (a <= 'Z'){
        System.out.print(a+" ");
        a++;
    }

}
}
