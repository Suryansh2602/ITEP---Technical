// EEEEE
// DDDD
// CCC
// BB
// A

class P16 {
         public static void main(String args[]) {
             char a = 'E';
             for (int i = 5; i>=1; i--) {
                for (int j=1; j<=i; j++) {
                     System.out.print(a);
            
                 }

                 a--;
                 System.out.println();
             }

         }
     }
    
