// 11111
// 22222
// 33333
// 44444
// 55555

class P22 {
    public static void main(String args[]) {
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= 5; j++) {
                // if (j <= (2 * i) - 1)
                System.out.print(i);
            }
            System.out.println();

        }

    }
}
