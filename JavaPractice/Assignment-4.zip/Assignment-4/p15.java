// WAP to print alphabets in Lowercase.
class P{
public static void main(String[] args) {
    char a = 'a';
    while (a <= 'z'){
        System.out.print(a+" ");
        a++;
    }

}
}