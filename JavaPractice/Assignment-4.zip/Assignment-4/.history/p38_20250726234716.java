// WAP to check whether entered number is Armstrong or not 
