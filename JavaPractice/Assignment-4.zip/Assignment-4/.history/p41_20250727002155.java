// WAP to find out LCM of a number
