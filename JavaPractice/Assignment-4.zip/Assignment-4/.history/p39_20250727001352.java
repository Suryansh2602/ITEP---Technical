// WAP to check whether entered number is strong or not
