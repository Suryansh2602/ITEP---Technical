public class p40 {
    
}
