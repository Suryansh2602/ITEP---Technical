// WAP to check whether entered number is palindrome or not
import java.util.Scanner;
class P{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the num: ");
        int n = sc.nextInt();
        int original = n;
        int rev = 0;
        while(n!=0){
            
        }
    }
}