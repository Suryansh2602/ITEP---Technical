// WAP to count no. Of even and odd digits in a number
