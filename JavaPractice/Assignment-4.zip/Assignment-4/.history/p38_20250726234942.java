// WAP to check whether entered number is Armstrong or not 
import java.util.Scanner;
class P{
    public static void mai(String... args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int n = sc.nextInt();
       

    }
}