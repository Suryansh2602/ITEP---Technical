// WAP to check whether entered number is palindrome or not
