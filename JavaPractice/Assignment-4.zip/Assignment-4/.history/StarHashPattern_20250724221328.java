import java.util.Scanner;

public class StarHashPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        int i = 0;  
        int spaces = 0;  

       
        }
    }

