// WAP to count no. Of even and odd digits in a number
import java.util.Scanner;
class P{
    public static void main(String[] args) {
        
    }
}